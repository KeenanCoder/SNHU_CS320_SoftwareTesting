//Keenan Vargas
//08/02/2026
//CS 320 - SNHU
package appointmentservice;

import java.util.*;

public class Appointment {

    //the appointment ID must be final since it cannot be updatable
    private final String appointmentId;
    //the appintment date object uses a Date field
    private Date appointmentDate;
    private String description;

    //constructor
    public Appointment(String appointmentId, Date appointmentDate, String description) {

        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }

        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }

        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    //get methods
    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }

    //throws exception if the appointment date is set to null or before the new date
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }

        this.appointmentDate = appointmentDate;
    }

    //throws an exception if the description is null or greater than 50 characters
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.description = description;
    }
}