//Keenan Vargas
//08/02/2026
//CS 320 - SNHU
package appointmentservice;

import java.util.*;

public class AppointmentService {

    //implements a hashmap to use IDs as keys to store the appointment
    private final HashMap<String, Appointment> appointments = new HashMap<>();

    //method that adds an appointment with its ID
    //throws an exception if it is null or if its not unique

    //uses the Appointment object to pass all the information relating to the
    //appointment object
    public void addAppointment(Appointment appointment) {

        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null");
        }

        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists");
        }

        appointments.put(appointment.getAppointmentId(), appointment);
    }

    //method that deletes an appointment ID
    //throws an exception if the ID is null or if appointment does not exists
    public void deleteAppointment(String appointmentId) {

        if (appointmentId == null || !appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment does not exist");
        }

        appointments.remove(appointmentId);
    }

    //get method for the appointment ID
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}
