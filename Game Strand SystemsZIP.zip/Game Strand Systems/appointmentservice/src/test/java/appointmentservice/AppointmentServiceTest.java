//Keenan Vargas
//08/02/2026
//CS 320 - SNHU
package appointmentservice;

//imports maven JUnit testing like assert methods (throw, equal, false, true, and null)
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.*;

//JUnit testing allows to verify that the AppointmentService java file behaves intendedly
//like valid inputs being accepted and invalid inputs throwing exceptions
public class AppointmentServiceTest {

    //method tests that verifies adding a new appointment equals the new appointment ID
    @Test
    public void testAddAppointment() {

        AppointmentService service = new AppointmentService();

        Appointment appointment = new Appointment(
                "001",
                new Date(System.currentTimeMillis() + 86400000),
                "Meeting"
        );

        service.addAppointment(appointment);

        assertEquals(
                appointment,
                service.getAppointment("001")
        );
    }

    //CHECK HERE BECAUSE IT MIGHT BE REDUNDANT TESTING BUT IT MAKES IT UNDER 80% COVERAGE*******************************
    
    //TO HERE****************************************

    //method tests that verifies that a duplicate appointment ID throws an exception
    @Test
    public void testDuplicateAppointmentIdNotAllowed() {

        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment first = new Appointment(
                "001",
                futureDate,
                "Meeting"
        );

        //recreates an appointment with the same ID
        Appointment second = new Appointment(
                "001",
                futureDate,
                "Another Meeting"
        );

        service.addAppointment(first);

        assertThrows(IllegalArgumentException.class, () ->
                service.addAppointment(second)
        );
    }

    //method tests that verifies setting the appointment
    @Test 
    public void testSetAppointmentDatePast(){
        Appointment appointment = new Appointment(
                 "1234567890", 
                 new Date(System.currentTimeMillis() + 86400000),
                "Test appointment" 
        ); 
        Date pastDate = new Date(System.currentTimeMillis() - 86400000);
         
        assertThrows( 
                IllegalArgumentException.class,
                () -> appointment.setAppointmentDate(pastDate) 
        );
    }

    //method tests that verifies setting a description longer than 50 characters throws an exception
    @Test
    public void testSetDescriptionTooLong(){
        Appointment appointment = new Appointment(
                "1234567890",
                new Date(System.currentTimeMillis() + 86400000),
                "Test appointment"
        );

        String longDescription = "This description is longer than fifty characters and invalid";

        assertThrows(
                IllegalArgumentException.class,
                () -> appointment.setDescription(longDescription)
        );
    }

    //method tests that verifies that deleting an appointment makes the ID null
    @Test
    public void testDeleteAppointment() {

        AppointmentService service = new AppointmentService();

        Appointment appointment = new Appointment(
                "001",
                new Date(System.currentTimeMillis() + 86400000),
                "Meeting"
        );

        service.addAppointment(appointment);

        service.deleteAppointment("001");

        assertNull(service.getAppointment("001"));
    }

    //method tests that verifies that an appointment that does not exist that wants to be deleted throws an exception
    //Uses lambda [which is the () -> part] so assertThrows can execute the constructor and verify if
    //it throws an exception
    @Test
    public void testDeleteNonExistingAppointment() {

        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () ->
                service.deleteAppointment("999")
        );
    }
}