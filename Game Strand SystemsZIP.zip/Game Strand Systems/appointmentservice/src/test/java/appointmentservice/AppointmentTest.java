//Keenan Vargas
//08/02/2026
//CS 320 - SNHU
package appointmentservice;

//imports maven JUnit testing like assert methods (throw, equal, false, true)
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.*;

//JUnit testing allows to verify that the Appointment java file behaves intendedly
//like valid inputs being accepted and invalid inputs throwing exceptions
public class AppointmentTest {

    //method tests that verifies that a an appointment was created succesfully
    @Test
    public void testAppointmentCreatedSuccessfully() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "12345",
                futureDate,
                "Doctor appointment"
        );

        assertEquals("12345", appointment.getAppointmentId());
        assertEquals("Doctor appointment", appointment.getDescription());
    }

    //method tests that verifies that a null appointment ID throws an exception
    @Test
    public void testAppointmentIdCannotBeNull() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () ->
                new Appointment(null, futureDate, "Test")
        );
    }

    //method tests that verifies that an appointment ID longer than 10 characters throws an exception
    @Test
    public void testAppointmentIdCannotExceedTenCharacters() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("12345678901", futureDate, "Test")
        );
    }

    //method tests that verifies that a past date for appointment date throws an exception
    @Test
    public void testAppointmentDateCannotBePast() {

        Date pastDate = new Date(System.currentTimeMillis() - 86400000);

        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("123", pastDate, "Test")
        );
    }

    //method tests that verifies that a appointment description longer than 50 characters throws an exception
    //Uses lambda [which is the () -> part] so assertThrows can execute the constructor and verify if
    //it throws an exception
    @Test
    public void testDescriptionCannotExceedFiftyCharacters() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () ->
                new Appointment(
                        "123",
                        futureDate,
                        "This description is longer than fifty characters and invalid"
                )
        );
    }

    //After using JaCoCo we try to have a 80% Coverage by adding more test**********************************
    //test to verify setting an appointment date to a valid date
    @Test
    public void testSetAppointmentDateValid(){
        Appointment appointment = new Appointment(
                "1234567890",
                new Date(System.currentTimeMillis() + 86400000),
                "Test appointment"
        );

        Date newDate = new Date(System.currentTimeMillis() + 172800000);

        appointment.setAppointmentDate(newDate);

        assertEquals(newDate, appointment.getAppointmentDate());
    }

    //test to verify setting an appointment date to a null date (should fail to pass test)
    @Test
    public void testSetAppointmentDateNull(){
        Appointment appointment = new Appointment(
                "1234567890",
                new Date(System.currentTimeMillis() + 86400000),
                "Test appointment"
        );

        assertThrows(
                IllegalArgumentException.class,
                () -> appointment.setAppointmentDate(null)
        );
    }

    //test to verify setting an appointment description to a valid description
    @Test
    public void testSetDescriptionValid(){
        Appointment appointment = new Appointment(
                "1234567890",
                new Date(System.currentTimeMillis() + 86400000),
                "Test appointment"
        );

        appointment.setDescription("New description");

        assertEquals("New description", appointment.getDescription());
    }

    //test to verify setting an appointment description to a null description (should fail to pass test)
    @Test
    public void testSetDescriptionNull(){
        Appointment appointment = new Appointment(
                "1234567890",
                new Date(System.currentTimeMillis() + 86400000),
                "Test appointment"
        );

        assertThrows(
                IllegalArgumentException.class,
                () -> appointment.setDescription(null)
        );
    }
}