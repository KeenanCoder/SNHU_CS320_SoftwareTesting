package contactservice;

public class Contact {

    //make the variable contactId final since it will be unchanged
    private final String contactId;
    //the remaining variables are private string.
    private String firstName, lastName, phoneNum, address;

    public Contact(String contactId, String firstName, String lastName,
        String phoneNum, String address){

        if(contactId == null || contactId.length() > 10){
            throw new IllegalArgumentException("Invalid Contact ID!");
        }
        if(firstName == null || firstName.length() > 10){
            throw new IllegalArgumentException("Invalid first name!");
        }
        if(lastName == null || lastName.length() > 10){
            throw new IllegalArgumentException("Invalid last name!");
        }
        if(phoneNum == null || !phoneNum.matches("\\d{10}")){
            throw new IllegalArgumentException("Invalid phone number!");
        }
        if(address == null || address.length() > 30){
            throw new IllegalArgumentException("Invalid address!");
        }

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNum = phoneNum;
        this.address = address;
    }

    //getter methods to get the objects
    public String getContactId(){
        return contactId;
    }
    public String getFirstName(){
        return firstName;
    }
    public String getLastName(){
        return lastName;
    }
    public String getPhoneNum(){
        return phoneNum;
    }
    public String getAddress(){
        return address;
    }

    //setters (except contactID) that throw
    //exception handling according to the criteria of the assignment
    public void setFirstName(String firstName){
        if(firstName == null || firstName.length() > 10){
            throw new IllegalArgumentException("Invalid first name");
        }
        this.firstName = firstName;
    }
    public void setLastName(String lastName){
        if(lastName == null || lastName.length() > 10){
            throw new IllegalArgumentException("Invalid last name");
        }
        this.lastName = lastName;
    }
    public void setPhoneNum(String phoneNum){
        if(phoneNum == null || !phoneNum.matches("\\d{10}")){
            throw new IllegalArgumentException("Invalid phone number");
        }
        this.phoneNum = phoneNum;
    }
    public void setAddress(String address){
        if(address == null || address.length() > 30){
            throw new IllegalArgumentException("Invalid address");
        }
        this.address = address;
    }
}