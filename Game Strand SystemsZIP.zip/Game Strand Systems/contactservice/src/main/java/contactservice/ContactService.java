package contactservice;

import java.beans.Transient;
//import all for the HashMap data structure
import java.util.*;

public class ContactService {

    //uses hashmap (data structure) because there is no database
    //so by using hashmap we store the key (contact id), and the data associated
    //with that key(contact information)

    //and final since the key cannot be changed
    private final HashMap<String, Contact> contacts = new HashMap<>();

    //method to add contacts with exception handling
    public void addContact(Contact contact){
        if(contact == null){
            throw new IllegalArgumentException("Contact cannot be null!");
        }
        if(contacts.containsKey(contact.getContactId())){
            throw new IllegalArgumentException("Duplicate contact ID");
        }
        contacts.put(contact.getContactId(), contact);
    }

    //method is for deleting the contactId from the system
    //calls a remove method with the contactId as a variable
    public void deleteContact(String contactId){
        if(!contacts.containsKey(contactId)){
            throw new IllegalArgumentException("Contact not found!");
        }
        contacts.remove(contactId);
    }

    //updates the first name by asking for the contactId associated with the name
    public void updateFirstName(String contactId, String firstName){
        Contact contact = contacts.get(contactId);

        if(contact ==null){
            throw new IllegalArgumentException("Contact not found!");
        }
        //if its a valid contact then it will set the variable firstName as the name of the user
        contact.setFirstName(firstName);
    }

    //updates the last name by asking for the contactId associated with the last name
    public void updateLastName(String contactId, String lastName){
        Contact contact = contacts.get(contactId);

        if(contact == null){
            throw new IllegalArgumentException("Contact not found!");
        }
        //if its a valid contact then it will set the variable lastName as the last name of the user
        contact.setLastName(lastName);
    }

    //updates the address by asking for the contactId associated with the address
    public void updateAddress(String contactId, String address){
        Contact contact = contacts.get(contactId);

        if(contact == null){
            throw new IllegalArgumentException("Contact not found!");
        }

        //if its a valid contact then it will set the variable lastName as the address of the user
        contact.setAddress(address);
    }

    //updates the address by asking for the contactId associated with the phone number
    public void updatePhoneNumber(String contactId, String phoneNum){
        Contact contact = contacts.get(contactId);

        if(contact == null){
            throw new IllegalArgumentException("Contact not found!");
        }

        //if its a valid contact then it will set the variable phoneNum as the phone number of the user
        contact.setPhoneNum(phoneNum);
    }

    public Contact getContact(String contactId){
        return contacts.get(contactId);
    }
}
