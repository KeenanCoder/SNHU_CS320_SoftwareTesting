package contactservice;

//sets up Junit to test
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    //method tests to see if the addContact method functions properly
    //
    @Test
    public void testAddContact(){

        //instiates an object in order to access ContactService class
        ContactService service = new ContactService();

        Contact contact = new Contact(
                "1",
                "Kim",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        service.addContact(contact);

        //assertEquals() ensures the newly added contact is retrieved according
        //to its contact Id
        assertEquals(contact, service.getContact("1"));
    }

    //test to see if there is nay duplicate Id
    //if so, it will be rejected
    @Test
    public void testDuplicateContactId(){

        //instiates an object in order to access ContactService class
        ContactService service = new ContactService();

        Contact contact1 = new Contact(
                "1",
                "Kim",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        Contact contact2 = new Contact(
                "1",
                "Bob",
                "Jones",
                "0987654321",
                "456 New Street"
        );

        service.addContact(contact1);

        //attempts to add a duplicate contact but asserThrows ensures
        //that the exception is thrown meaning the testing passes
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    //test if a contact can be deleted
    @Test
    public void testDeleteContact(){

        //instiates an object in order to access ContactService class
        ContactService service = new ContactService();

        Contact contact = new Contact(
                "1",
                "Kim",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        service.addContact(contact);

        service.deleteContact("1");

        //ensures that the deleted contact Id cannot be found
        assertNull(service.getContact("1"));
    }

    //in ContactService it throws an illegalargument that states if the contact
    //trying to be deleted does not exist, which is what this method is testing
    @Test
    public void testDeleteMissingContact(){

        //instiates an object in order to access ContactService class
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("99");
        });

    }

    //test to see if the contact fileds can be updated correctly
    @Test
    public void testUpdateContact(){

        //instiates an object in order to access ContactService class
        ContactService service = new ContactService();

        Contact contact = new Contact(
                "1",
                "Kim",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        //adds the new contact
        service.addContact(contact);

        //updates all the information associated with the contact
        service.updateFirstName("1", "Bob");
        service.updateLastName("1", "Jones");
        service.updatePhoneNumber("1", "0987654321");
        service.updateAddress("1", "456 New Street");


        //ensures that the recently updated information is called when referenced (by the get method)
        assertEquals("Bob", service.getContact("1").getFirstName());
        assertEquals("Jones", service.getContact("1").getLastName());
        assertEquals("0987654321", service.getContact("1").getPhoneNum());
        assertEquals("456 New Street", service.getContact("1").getAddress());
    }

    //test to see any missing update contact
    @Test
    public void testUpdateMissingContact(){

        //instiates an object in order to access ContactService class
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("99", "Bob");
        });
    }
}