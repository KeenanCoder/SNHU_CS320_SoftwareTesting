package contactservice;

//sets up the Junit to test
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    //method tests to see if the contact is valid
    @Test
    public void testValidContact(){

        //instiates an object in order to access Contact class
        Contact contact = new Contact(
                "1",
                "Kim",
                "Smith",
                "1234567890",
                "123 Main Street"
        );
        //each of these assertEquals methods must expect the variable to be stored in their appropiate place
        //so 1 will be stored as the contactId for example
        assertEquals("1", contact.getContactId());
        assertEquals("Kim", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("1234567890", contact.getPhoneNum());
        assertEquals("123 Main Street", contact.getAddress());
    }

    //method tests to see if the contact is invalid
    //calls assertThrows (from the Junit) since it expects an error
    //and it passes because although an error happened it did expect it so the testing worked.
    @Test
    public void testInvalidContactId(){

        // Test null contact ID
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Kim", "Smith", "1234567890", "123 Main Street");
        });

        // Test contact ID longer than 10 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Kim", "Smith", "1234567890", "123 Main Street");
        });
    }

    //method tests to see if the first name is invalid
    //calls assertThrows (from the Junit) since it expects an error
    //and it passes because although an error happened it did expect it so the testing worked.
    @Test
    public void testInvalidFirstName(){

        // Test null first name
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", null, "Smith", "1234567890", "123 Main Street");
        });

        // Test first name longer than 10 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Christopher", "Smith", "1234567890", "123 Main Street");
        });
    }

    //method tests to see if the last name is invalid
    //calls assertThrows (from the Junit) since it expects an error
    //and it passes because although an error happened it did expect it so the testing worked.
    @Test
    public void testInvalidLastName(){

        // Test null last name
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Kim", null, "1234567890", "123 Main Street");
        });

        // Test last name longer than 10 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Kim", "Longlastname", "1234567890", "123 Main Street");
        });
    }

    //method tests to see if the phone number is invalid
    //calls assertThrows (from the Junit) since it expects an error
    //and it passes because although an error happened it did expect it so the testing worked.
    @Test
    public void testInvalidPhoneNum(){

        // Test null phone
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Kim", "Smith", null, "123 Main Street");
        });

        // Test phone that is not exactly 10 digits
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Kim", "Smith", "12345", "123 Main Street");
        });

        // Test phone containing letters
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Kim", "Smith", "123456789A", "123 Main Street");
        });
    }

    //method tests to see if the address is invalid
    //calls assertThrows (from the Junit) since it expects an error
    //and it passes because although an error happened it did expect it so the testing worked.
    @Test
    public void testInvalidAddress(){

        // Test null address
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Kim", "Smith", "1234567890", null);
        });

        // Test address longer than 30 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "1",
                    "Kim",
                    "Smith",
                    "1234567890",
                    "This address is definitely longer than thirty characters"
            );
        });
    }

    //method tests to see if the information for each item is updated
    //successfully
    @Test
    public void testUpdateFields(){

        //instiates an object in order to access Contact class
        Contact contact = new Contact(
                "1",
                "Kim",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        //sets the information according to contact object's parameters
        contact.setFirstName("Bob");
        contact.setLastName("Jones");
        contact.setPhoneNum("0987654321");
        contact.setAddress("456 New Street");

        //tests to see if the setter methods succesfully updated the objects information
        assertEquals("Bob", contact.getFirstName());
        assertEquals("Jones", contact.getLastName());
        assertEquals("0987654321", contact.getPhoneNum());
        assertEquals("456 New Street", contact.getAddress());
    }

    //After using JaCoCo we try to have a 80% Coverage by adding more test**********************************

    //test to verify that adding a null contact throws an exception
    @Test
    public void testAddNullContact(){
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(null);
        });
    }

    //test to verify that updating the last name of a missing contact throws an exception
    @Test
    public void testUpdateMissingLastName(){
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateLastName("99", "Jones");
        });
    }

    //test to verify that updating the address of a missing contact throws an exception
    @Test
    public void testUpdateMissingAddress(){
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateAddress("99", "123 Main Street");
        });
    }

    //test to verify that updating the phone number of a missing contact throws an exception
    @Test
    public void testUpdateMissingPhoneNum(){
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updatePhoneNumber("99", "1234567890");
        });
    }
}