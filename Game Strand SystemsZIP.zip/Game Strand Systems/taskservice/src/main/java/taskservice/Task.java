//Keenan Vargas
//07/25/2026
//CS 320 - SNHU
package taskservice;

public class Task {

    //make the variable taskId final since it is stated to be a unique task
    //id String
    private final String taskId;
    //the remaining variables are private string fields since they can be changed
    private String name, description;

    public Task(String taskId, String name, String description){

        if(taskId == null || taskId.length() > 10){
            throw new IllegalArgumentException("Invalid Task ID!");
        }
        if(name == null || name.length() > 20){
            throw new IllegalArgumentException("Invalid Task Name!");
        }
        if(description == null ||description.length() > 50){
            throw new IllegalArgumentException("Invalid Task Description!");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    //getter methods to return the values 
    public String getTaskId(){
        return taskId;
    }
    public String getTaskName(){
        return name;
    }
    public String getTaskDescription(){
        return description;
    }

    //setters for updateable String fields(since task ID cannot be changed) 
    //that throw exception handling according to the criteria of the assignment
    public void setTaskName(String name){
        if(name == null || name.length() > 20){
            throw new IllegalArgumentException("Invalid Task Name");
        }
        this.name = name;
    }
    public void setTaskDescription(String description){
        if(description == null || description.length() > 50){
            throw new IllegalArgumentException("Invalid Task Description");
        }
        this.description = description;
    }
}