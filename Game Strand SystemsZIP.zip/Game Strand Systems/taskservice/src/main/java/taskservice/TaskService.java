package taskservice;

import java.util.HashMap;

public class TaskService {

    //uses hashmap (data structure) because there is no database
    //so by using hashmap we store the key (task ID), and the data associated
    //with that key(test information)

    //and final for the field since the key should not be changed
    //(since it is tied to the task)
    private final HashMap<String, Task> tasks = new HashMap<>();

    //method to add tasks with exception handling like
    //if task is null or a duplicate
    public void addTask(Task task){
        if(task == null){
            throw new IllegalArgumentException("Task cannot be null!");
        }
        if(tasks.containsKey(task.getTaskId())){
            throw new IllegalArgumentException("Duplicate task ID");
        }
        tasks.put(task.getTaskId(), task);
    }

    //method is for deleting the task associated with the ID from the system
    //by searching for the task ID and if it doesn't exist, it will throw
    //a "Task not found" exception handling
    public void deleteTask(String taskId){
        if(!tasks.containsKey(taskId)){
            throw new IllegalArgumentException("Task not found!");
        }
        tasks.remove(taskId);
    }

    //updates the task name by asking for the taskId associated with the name
    //as parameters
    public void updateTaskName(String taskId, String name){
        Task task = tasks.get(taskId);

        if(task ==null){
            throw new IllegalArgumentException("Task not found!");
        }
        //if its a valid task ID then it will set the task name to whatever the
        //variable name is assigned to
        task.setTaskName(name);
    }


    //updates the task descriptions by using the taskId and the description
    //as parameters
    public void updateTaskDescription(String taskId, String description){
        Task task = tasks.get(taskId);

        if(task == null){
            throw new IllegalArgumentException("Task not found!");
        }

        //if its a valid task ID then it will set the task description to whatever the
        //variable description is assigned to
        task.setTaskDescription(description);
    }

    public Task getTask(String taskId){
        return tasks.get(taskId);
    }
}
