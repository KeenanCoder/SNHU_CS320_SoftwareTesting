package taskservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    //test to see if adding a task will function properly by first calling the TaskService class for methods
    //then it adds parameters to the task like the ID, the name of that task and its description
    @Test
    public void testAddTask() {
        TaskService service = new TaskService();
        Task task = new Task("100", "Homework", "Complete CS 320 Assignment");

        //it calls the addTask method from TaskService and by calling the assertsEquals method,
        //using the assertsEquals method, it ensures that if it returns the desired task, it passes the test
        service.addTask(task);
        assertEquals(task, service.getTask("100"));
    }

    //test to see if duplicate task IDs function by first creating a new task ID, then
    //it checks to see if it passes by throwing an exception using lambda (the arrow and brackets) 
    @Test
    public void testDuplicateTaskId() {
        TaskService service = new TaskService();

        //adds task 1
        service.addTask(new Task("100", "Task1", "Description"));
        //test to see if it throws an exception according to task 2 (inside hte lambda)
        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(new Task("100", "Task2", "Description"));
        });
    }

    //test to see if the delete task method works by adding a new task and deleting it after
    //then it will call the getTask method inside the assert method using the task ID 
    //to see if it returns (which it shouldn't)
    @Test
    public void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("100", "Task", "Description");

        service.addTask(task);
        service.deleteTask("100");
        assertNull(service.getTask("100"));
    }

    //test to see if the update task name functions by adding a new task and updating the name by calling the ID and
    //what new name it will assign it then it will call the getTask and getTaskName method inside the asserts method
    @Test
    public void testUpdateTaskName() {
        TaskService service = new TaskService();

        service.addTask(new Task("100", "Old", "Description"));
        service.updateTaskName("100", "New");
        assertEquals("New", service.getTask("100").getTaskName());
    }

    //test to see if the update task description functions by adding a new task and updating the description after 
    //by calling the ID and what new name it will assign it
    //then it will call the getTask and getTaskDescription method inside the asserts method
    @Test
    public void testUpdateTaskDescription() {
        TaskService service = new TaskService();

        service.addTask(new Task("100", "Task", "Old Description"));
        service.updateTaskDescription("100", "New Description");
        assertEquals("New Description", service.getTask("100").getTaskDescription());
    }

    //test to see if it prevents an update on a task that doesn't exist (it shouldn't)
    //by throwing an exception if it can update a task name that doesn't exist
    @Test
    public void testUpdateNonexistentTask() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("999", "New");
        });
    }

    //test to see if it prevents a deletion on a task that doesn't exist (it shouldn't)
    //by throwing an exception if it can delete a task that doesn't exist
    @Test
    public void testDeleteNonexistentTask() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("999");
        });
    }
}