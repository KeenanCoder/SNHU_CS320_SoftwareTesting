package taskservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    //test to see if the newly added task object contains information like the ID, name and description
    //all match the what assertEquals wants to call
    @Test
    public void testValidTaskCreation() {

        Task task = new Task("12345", "Homework", "Complete CS 320 Assignment");

        assertEquals("12345", task.getTaskId());
        assertEquals("Homework", task.getTaskName());
        assertEquals("Complete CS 320 Assignment", task.getTaskDescription());
    }

    //test to find any invalid IDs by calling an exception with lambda and having the
    //IDs set to null or over 10 characters
    @Test
    public void testInvalidTaskId() {

        //test IDs that are null to be thrown an exception
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Task", "Description");
        });

        //test IDs that are over 10 characters to be thrown an exception
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Task", "Description");
        });
    }

    //test to find any invalid task names by calling an exception with lambda and having the
    //names set to null or over 20 characters
    @Test
    public void testInvalidName() {

        //test names that are null to be thrown an exception
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", null, "Description");
        });

        //test names that are over 20 characters in the string to be thrown an exception
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "ABCDEFGHIJKLMNOPQRSTU", "Description");
        });
    }

    //test to find any invalid task description by calling an exception with lambda and having the
    //descriptions set to null or over 50 characters
    @Test
    public void testInvalidDescription() {

        //test descriptions that are null to be thrown an exception
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Task", null);
        });

        //test descriptions that are over 50 characters in length in the string to be thrown an exception
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Task",
                "This description is definitely longer than fifty characters and should be thrown an exception.");
        });
    }

    //test to see if it can find the task by its ID and update the name after
    //First it adds a new task then sets the task name to new and then it calls
    //the asserts method to find the expected name that was updated
    @Test
    public void testUpdateName() {

        Task task = new Task("123", "Old", "Description");

        task.setTaskName("New");
        assertEquals("New", task.getTaskName());
    }

    //test to see if it can find the task by its ID and update the description after
    //First it adds a new task the sets then task descriptions to new and then it calls
    //the asserts method to find the expected descriptions that was updated
    @Test
    public void testUpdateDescription() {

        Task task = new Task("123", "Task", "Old");

        task.setTaskDescription("New Description");
        assertEquals("New Description", task.getTaskDescription());
    }
}